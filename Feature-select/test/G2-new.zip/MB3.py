def Inter_IAMB(targets):
    result = []
    for target in targets:
        mb = [0 if n_states[i] > 1 and n_states[target] > 1 else -1 for i in range(n_vars)]
        removals = [0 for _ in range(n_vars)]
        mb[target] = -1

        n_conds = 0
        cond = np.full(max_max_cond_size, -1, dtype=int)
        dep = np.zeros(n_vars, dtype=float)

        # 增长阶段
        while True:
            stop = True

            if n_conds < max_max_cond_size:
                dep[:] = 0.0

                for i in range(n_vars):
                    if mb[i] == 0:
                        dep[i] = compute_dep(i, target, cond)

                        if dep[i] >= 1.0:
                            stop = False

            if not stop:
                aux = k_greedy(dep)
                mb[aux] = 1
                cond[n_conds] = aux
                n_conds += 1

                # 开始剪枝
                dep[:] = 0.0

                for i in range(n_vars):
                    if mb[i] == 1 and removals[i] < 10:
                        if i in cond:
                            index = np.where(cond == i)[0][0]
                            cond[index:-1] = cond[index + 1:]
                            cond[-1] = -1  # 最后一位置为-1

                        dep[i] = compute_dep(i, target, cond)

                        if dep[i] <= -1.0:
                            n_conds -= 1
                            mb[i] = 0
                            removals[i] += 1  # 避免死循环
                        else:
                            if cond[-1] == -1:
                                cond[-1] = i
            else:
                break

        # 最终调整
        mb = [0 if x == -1 else x for x in mb]
        result.append(mb)

    # 保存结果
    relation_matrix = np.array(result)
    np.savetxt('result.txt', relation_matrix)
