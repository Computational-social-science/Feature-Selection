void Inter_IAMB(int target)
{
    int i, j, k,stop, n_conds, aux;
    int *mb, *cond,*removals;
    double *dep;

    mb = new int[n_vars];
    removals=new int[n_vars];

    for (i = 0; i < n_vars; i++)
    {
        if (n_states[i] > 1 && n_states[target] > 1)
            mb[i] = 0;
        else
            mb[i] = -1;

        removals[i]=0;
    }
    mb[target] = -1;

    n_conds = 0;
    cond = new int[max_max_cond_size];
    for (i = 0; i < max_max_cond_size; i++)
        cond[i] = -1;

    dep = new double[n_vars];

    do {
        stop = 1;

        if (n_conds < max_max_cond_size)
        {
            for (i = 0; i < n_vars; i++)
                dep[i] = (double)0.0;

            for (i = 0; i < n_vars; i++)
            {
                if (mb[i] == 0)
                {
                    dep[i] = compute_dep(i, target, cond);

                    if (dep[i] >= (double)1.0)
                    {
                        stop = 0;
                    }
                }
            }
        }

        if (stop == 0)
        {
            aux = k_greedy(dep);
            mb[aux] = 1;
            cond[n_conds] = aux;
            n_conds++;
            //the end of growth.


            //Start to cut, if there is no node to join in the growth phase, there is no need to make a cut.
            for (i = 0; i < n_vars; i++)
                dep[i] = (double)0.0;

            for (i = 0; i < n_vars; i++)
            {
                if (mb[i] == 1&& removals[i]<10)
                {
                    for (j = 0; j < n_conds; j++)
                        if (cond[j] == i)
                        {
                            for (k = j; k < n_conds - 1; k++)
                                cond[k] = cond[k + 1];
                            cond[n_conds - 1] = -1;

                            j = n_conds;//end loop
                        }

                    dep[i] = compute_dep(i, target, cond);

                    //cond[n_conds - 1] = i;

                    if (dep[i] <= (double)(-1.0))
                    {
                        n_conds--;
                        mb[i] = 0;
                        removals[i]++; //To avoid endless loop.
                    }
                    else
                    {
                        cond[n_conds - 1] = i;
                    }
                }
            }
        }

    } while (stop == 0);

    for (int var = 0; var < n_vars; ++var) {
        if (mb[var]==-1) {
            mb[var]=0;
        }
    }
    report_mb(target, mb);

    delete[] mb;
    delete[] cond;
    delete[] dep;
}
